import java.util.Scanner;
import java.time.LocalDate;

public class VehicleRentalApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RentalSystem rentalSystem = RentalSystem.getInstance();
        rentalSystem.loadData();

        while (true) {
        	System.out.println("\n1: Add Vehicle\n" + 
                                  "2: Add Customer\n" + 
                                  "3: Rent Vehicle\n" + 
                                  "4: Return Vehicle\n" + 
                                  "5: Display Available Vehicles\n" + 
                                  "6: Show Rental History\n" + 
                                  "0: Exit\n");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("1. Car");
                    System.out.println("2. Minibus");
                    System.out.println("3. Pickup Truck");
                    int type = scanner.nextInt();
                    scanner.nextLine(); // consume newline

                    System.out.print("Enter license plate: ");
                    String plate = scanner.nextLine().toUpperCase();
                    System.out.print("Enter make: ");
                    String make = scanner.nextLine();
                    System.out.print("Enter model: ");
                    String model = scanner.nextLine();
                    System.out.print("Enter year: ");
                    int year = scanner.nextInt();
                    scanner.nextLine();

                    Vehicle vehicle;

                    if (type == 1) {
                        System.out.print("Enter number of seats: ");
                        int seats = scanner.nextInt();
                        scanner.nextLine();
                        vehicle = new Car(make, model, year, seats);
                    } else if (type == 2) {
                        System.out.print("Is accessible? (true/false): ");
                        boolean isAccessible = scanner.nextBoolean();
                        scanner.nextLine();
                        vehicle = new Minibus(make, model, year, isAccessible);
                    } else if (type == 3) {
                        System.out.print("Enter the cargo size: ");
                        double cargoSize = scanner.nextDouble();
                        scanner.nextLine();
                        System.out.print("Has trailer? (true/false): ");
                        boolean hasTrailer = scanner.nextBoolean();
                        scanner.nextLine();
                        vehicle = new PickupTruck(make, model, year, cargoSize, hasTrailer);
                    } else {
                        vehicle = null;
                    }

                    if (vehicle != null) {
                        vehicle.setLicensePlate(plate);
                        boolean added = rentalSystem.addVehicle(vehicle);
                        if (added) {
                            System.out.println("Vehicle added successfully.");
                        } else {
                            System.out.println("Vehicle not added successfully.");
                        }
                    } else {
                        System.out.println("Vehicle not added successfully.");
                    }
                    break;

                case 2:
                    System.out.print("Enter customer ID: ");
                    int cid = scanner.nextInt();
                    scanner.nextLine(); // consume leftover newline
                    System.out.print("Enter name: ");
                    String cname = scanner.nextLine();

                    boolean customerAdded = rentalSystem.addCustomer(new Customer(cid, cname));
                    if (customerAdded) {
                        System.out.println("Customer added successfully.");
                    } else {
                        System.out.println("Customer not added.");
                    }
                    break;

                case 3:
                    rentalSystem.displayVehicles(Vehicle.VehicleStatus.Available);
                    System.out.print("Enter license plate: ");
                    String rentPlate = scanner.nextLine().toUpperCase();

                    System.out.println("Registered Customers:");
                    rentalSystem.displayAllCustomers();
                    System.out.print("Enter customer ID: ");
                    int cidRent = scanner.nextInt();
                    System.out.print("Enter rental amount: ");
                    double rentAmount = scanner.nextDouble();
                    scanner.nextLine();

                    Vehicle vehicleToRent = rentalSystem.findVehicleByPlate(rentPlate);
                    Customer customerToRent = rentalSystem.findCustomerById(cidRent);

                    if (vehicleToRent == null || customerToRent == null) {
                        System.out.println("Vehicle or customer not found.");
                        break;
                    }

                    boolean rented = rentalSystem.rentVehicle(
                            vehicleToRent, customerToRent, LocalDate.now(), rentAmount);
                    if (!rented) {
                        System.out.println("Rent operation failed.");
                    }
                    break;

                case 4:
                    rentalSystem.displayVehicles(Vehicle.VehicleStatus.Rented);
                    System.out.print("Enter license plate: ");
                    String returnPlate = scanner.nextLine().toUpperCase();

                    System.out.println("Registered Customers:");
                    rentalSystem.displayAllCustomers();
                    System.out.print("Enter customer ID: ");
                    int cidReturn = scanner.nextInt();
                    System.out.print("Enter any additional return fees: ");
                    double returnFees = scanner.nextDouble();
                    scanner.nextLine();

                    Vehicle vehicleToReturn = rentalSystem.findVehicleByPlate(returnPlate);
                    Customer customerToReturn = rentalSystem.findCustomerById(cidReturn);

                    if (vehicleToReturn == null || customerToReturn == null) {
                        System.out.println("Vehicle or customer not found.");
                        break;
                    }

                    boolean returned = rentalSystem.returnVehicle(
                            vehicleToReturn, customerToReturn, LocalDate.now(), returnFees);
                    if (!returned) {
                        System.out.println("Return operation failed.");
                    }
                    break;

                case 5:
                    rentalSystem.displayVehicles(Vehicle.VehicleStatus.Available);
                    break;
                
                case 6:
                    rentalSystem.displayRentalHistory();
                    break;
                    
                case 0:
                	scanner.close();
                    System.exit(0);
            }
        }
    }
}